package com6510.oak.shef.ac.uk;

/**
 * Maps Interface
 */
public interface MapsInterface {
    void thumbnailClick(Photo photo);
}
